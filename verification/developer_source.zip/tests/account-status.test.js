import test from 'node:test';
import assert from 'node:assert/strict';
import {workerLoginStatus} from '../public/modules/accounts.js';
const now=Date.parse('2026-10-29T00:00:00Z');
const ready={employee_active:true,profile_id:'worker',profile_active:true,enabled:true,state:'ready'};
test('worker display distinguishes disabled, unissued, expired and ready accounts',()=>{
 assert.equal(workerLoginStatus({...ready,employee_active:false},now),'미사용 · 로그인 차단');
 assert.equal(workerLoginStatus({...ready,profile_id:null},now),'계정 미발급');
 assert.equal(workerLoginStatus({...ready,state:'pending',expires_at:new Date(now-1).toISOString()},now),'초기번호 만료 · 재발급 필요');
 assert.equal(workerLoginStatus({...ready,state:'pending',expires_at:null},now),'초기번호 만료 · 재발급 필요');
 assert.equal(workerLoginStatus({...ready,state:'pending',expires_at:new Date(now+60000).toISOString()},now),'첫 비밀번호 설정 대기');
 assert.equal(workerLoginStatus({...ready,profile_active:false},now),'로그인 중지');
 assert.equal(workerLoginStatus(ready,now),'사용 중');
});
